
def get_line(x0, y0, x1, y1):
    return []

if __name__ == "__main__":
    print(get_line(0, 0, 10, 8))